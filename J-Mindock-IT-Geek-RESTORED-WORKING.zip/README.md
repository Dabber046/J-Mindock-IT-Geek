# J-Mindock IT Geek

Cloudflare Pages-ready React/Vite website.

## Cloudflare Pages settings

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: leave blank or `/` only if the files are at repo root
- Deploy command: not used in Pages

## Important

This project does not use Wrangler, Workers, Functions, or Cloudflare API tokens.

The repo root must show:

- `index.html`
- `package.json`
- `src/`
- `public/`
- `vite.config.ts`

## Shopify payment link

Add this environment variable in Cloudflare Pages when ready:

`VITE_SHOPIFY_PAYMENT_URL=https://your-shopify-checkout-or-invoice-link`

If this variable is not set, the site shows an email-based invoice request button instead.
