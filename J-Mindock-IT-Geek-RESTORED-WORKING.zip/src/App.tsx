const shopifyPaymentUrl = import.meta.env.VITE_SHOPIFY_PAYMENT_URL || '';

const services = [
  'Custom website design and full-stack development',
  'PC builds, upgrades, and gaming system optimization',
  'Computer diagnostics, repairs, and setup support',
  'Small business tech support and workflow help',
];

export default function App() {
  const email = 'Mindock-IT-Geeks@outlook.com';
  const phone = '269.249.6596';
  const quoteSubject = encodeURIComponent('New service request for J-Mindock IT Geek');
  const quoteBody = encodeURIComponent('Name:\nPhone:\nService needed:\nPreferred time:\nMessage:');

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/90 backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="#home" className="text-lg font-black tracking-wide text-cyan-300">
            J-Mindock IT Geek
          </a>
          <div className="hidden gap-6 text-sm text-slate-200 md:flex">
            <a className="hover:text-cyan-300" href="#services">Services</a>
            <a className="hover:text-cyan-300" href="#payments">Payments</a>
            <a className="hover:text-cyan-300" href="#contact">Contact</a>
          </div>
        </nav>
      </header>

      <main id="home">
        <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-[1.2fr_.8fr] md:items-center">
          <div>
            <p className="mb-4 inline-flex rounded-full border border-cyan-300/30 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-200">
              Founded in 2025 • Web Development • PC Builds • Tech Support
            </p>
            <h1 className="text-4xl font-black leading-tight md:text-6xl">
              Modern tech solutions for businesses, gamers, and everyday users.
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-slate-300">
              J-Mindock IT Geek helps with professional websites, custom PC builds,
              diagnostics, repairs, setup, and ongoing technology support.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href={`mailto:${email}?subject=${quoteSubject}&body=${quoteBody}`} className="rounded-xl bg-cyan-300 px-6 py-3 font-bold text-slate-950 transition hover:bg-cyan-200">
                Request Service
              </a>
              <a href={`tel:${phone.replace(/\D/g, '')}`} className="rounded-xl border border-white/20 px-6 py-3 font-bold text-white transition hover:border-cyan-300 hover:text-cyan-200">
                Call {phone}
              </a>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-2xl shadow-cyan-950/50">
            <h2 className="text-2xl font-black text-cyan-200">Founder & CEO</h2>
            <p className="mt-2 text-xl font-semibold">Jared J. Mindock</p>
            <p className="mt-4 text-slate-300">
              Built for practical, reliable support — from clean websites to dependable computer systems.
            </p>
            <div className="mt-6 space-y-3 text-sm text-slate-200">
              <p><strong>Email:</strong> {email}</p>
              <p><strong>Phone:</strong> {phone}</p>
              <p><strong>Established:</strong> 2025</p>
            </div>
          </div>
        </section>

        <section id="services" className="border-y border-white/10 bg-white/[0.03] px-5 py-16">
          <div className="mx-auto max-w-6xl">
            <h2 className="text-3xl font-black">Services Offered</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-2">
              {services.map((service) => (
                <div key={service} className="rounded-2xl border border-white/10 bg-slate-900 p-6">
                  <p className="text-lg font-semibold text-slate-100">{service}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="payments" className="mx-auto max-w-6xl px-5 py-16">
          <div className="rounded-3xl border border-cyan-300/20 bg-cyan-300/10 p-8">
            <h2 className="text-3xl font-black">Invoice Payments</h2>
            <p className="mt-4 max-w-3xl text-slate-300">
              Shopify invoice payments can be connected here with a draft order or payment link.
              Until your live Shopify link is added, customers can request an invoice by email.
            </p>
            <div className="mt-6 flex flex-wrap gap-4">
              {shopifyPaymentUrl ? (
                <a href={shopifyPaymentUrl} className="rounded-xl bg-cyan-300 px-6 py-3 font-bold text-slate-950 transition hover:bg-cyan-200">
                  Pay Invoice
                </a>
              ) : (
                <a href={`mailto:${email}?subject=${encodeURIComponent('Invoice payment request')}`} className="rounded-xl bg-cyan-300 px-6 py-3 font-bold text-slate-950 transition hover:bg-cyan-200">
                  Request Payment Link
                </a>
              )}
            </div>
          </div>
        </section>

        <section id="contact" className="border-t border-white/10 px-5 py-16">
          <div className="mx-auto max-w-6xl">
            <h2 className="text-3xl font-black">Contact</h2>
            <p className="mt-4 text-slate-300">Ready to start a website, repair, upgrade, or support request?</p>
            <div className="mt-6 flex flex-wrap gap-4">
              <a href={`mailto:${email}?subject=${quoteSubject}&body=${quoteBody}`} className="rounded-xl bg-white px-6 py-3 font-bold text-slate-950">
                Email {email}
              </a>
              <a href={`tel:${phone.replace(/\D/g, '')}`} className="rounded-xl border border-white/20 px-6 py-3 font-bold">
                Call {phone}
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 px-5 py-8 text-center text-sm text-slate-400">
        © 2025 J-Mindock IT Geek. Founded by Jared J. Mindock.
      </footer>
    </div>
  );
}
