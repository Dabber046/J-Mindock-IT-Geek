import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const SHOPIFY_PAYMENT_URL = '';
const EMAIL = 'Mindock-IT-Geeks@outlook.com';
const PHONE = '269.249.6596';

const services = [
  {
    title: 'Website Development',
    text: 'Clean, responsive websites for small businesses, personal brands, and local services. Built with modern layouts, strong calls-to-action, and deployment support.'
  },
  {
    title: 'PC Builds & Upgrades',
    text: 'Custom gaming, work, and everyday PC builds with part planning, assembly help, upgrade advice, and performance-focused setup.'
  },
  {
    title: 'Tech Support & Repair',
    text: 'Troubleshooting, software cleanup, hardware diagnostics, device setup, printer help, email setup, and practical support for home and business tech.'
  },
  {
    title: 'Business Tech Setup',
    text: 'Help with domains, email, hosting, forms, online payments, basic automations, and the tools needed to keep your business moving.'
  }
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', service: 'Website Development', message: '' });

  const paymentHref = SHOPIFY_PAYMENT_URL || `mailto:${EMAIL}?subject=Invoice Payment Link Request&body=Hello Jared,%0D%0A%0D%0AI would like to request a payment link or invoice for Mindock IT Geeks services.%0D%0A%0D%0AThank you.`;

  const submitContact = (event) => {
    event.preventDefault();
    const subject = encodeURIComponent(`New ${form.service} Request from ${form.name || 'Website Visitor'}`);
    const body = encodeURIComponent(`Name: ${form.name}\nEmail: ${form.email}\nService: ${form.service}\n\nMessage:\n${form.message}`);
    window.location.href = `mailto:${EMAIL}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="site-shell">
      <header className="navbar">
        <a className="brand" href="#home" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark">MI</span>
          <span>
            <strong>Mindock IT Geeks</strong>
            <small>Est. 2025</small>
          </span>
        </a>
        <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          ☰
        </button>
        <nav className={menuOpen ? 'open' : ''}>
          <a href="#services" onClick={() => setMenuOpen(false)}>Services</a>
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
          <a href="#payments" onClick={() => setMenuOpen(false)}>Payments</a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
        </nav>
      </header>

      <main>
        <section id="home" className="hero section">
          <div className="hero-copy">
            <p className="eyebrow">Founder & CEO • Jared J. Mindock</p>
            <h1>Modern web development, custom PC builds, and practical tech support.</h1>
            <p className="hero-text">
              Mindock IT Geeks helps local customers and small businesses get reliable technology without the confusing runaround.
            </p>
            <div className="hero-actions">
              <a className="button primary" href="#contact">Request Service</a>
              <a className="button secondary" href={paymentHref}>Pay Invoice</a>
            </div>
          </div>
          <div className="hero-card">
            <h2>What we offer</h2>
            <ul>
              <li>Responsive business websites</li>
              <li>PC building and upgrades</li>
              <li>Diagnostics and tech repair</li>
              <li>Domains, email, and hosting guidance</li>
            </ul>
          </div>
        </section>

        <section id="services" className="section">
          <div className="section-heading">
            <p className="eyebrow">Services</p>
            <h2>Built for real-world tech needs.</h2>
          </div>
          <div className="service-grid">
            {services.map((item) => (
              <article className="service-card" key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="about" className="section split-section">
          <div>
            <p className="eyebrow">About</p>
            <h2>Founded in 2025 with a hands-on approach.</h2>
          </div>
          <p>
            Mindock IT Geeks was created to bring dependable, understandable, and professional technology help to customers who need websites, PC support, repairs, and setup guidance. The goal is simple: make technology work better for you.
          </p>
        </section>

        <section id="payments" className="section payment-panel">
          <div>
            <p className="eyebrow">Payments</p>
            <h2>Shopify-ready invoice payments.</h2>
            <p>
              Customers can request a payment link or pay an invoice using a Shopify checkout link once the invoice is created.
            </p>
          </div>
          <a className="button primary" href={paymentHref}>Pay or Request Invoice</a>
        </section>

        <section id="contact" className="section contact-section">
          <div>
            <p className="eyebrow">Contact</p>
            <h2>Tell us what you need help with.</h2>
            <p>Email: <a href={`mailto:${EMAIL}`}>{EMAIL}</a></p>
            <p>Phone: <a href="tel:12692496596">{PHONE}</a></p>
          </div>
          <form onSubmit={submitContact} className="contact-form">
            <label>
              Name
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
            </label>
            <label>
              Email
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
            </label>
            <label>
              Service
              <select value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })}>
                {services.map((item) => <option key={item.title}>{item.title}</option>)}
              </select>
            </label>
            <label>
              Message
              <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Tell me about the project or issue." />
            </label>
            <button className="button primary" type="submit">Send Request</button>
          </form>
        </section>
      </main>

      <footer>
        <p>© {new Date().getFullYear()} Mindock IT Geeks. Founded in 2025.</p>
        <p>Jared J. Mindock • Founder & CEO</p>
      </footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
