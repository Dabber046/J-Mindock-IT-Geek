# Mindock IT Geeks

Cloudflare Pages safe React/Vite website.

## Cloudflare Pages Settings

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: leave blank or `/`
- Deploy command: leave blank

Do not add `wrangler.toml`, `functions/`, or Worker deploy settings unless you intentionally convert this into a Worker app.

## Shopify invoice button

Edit `src/main.jsx` and replace `SHOPIFY_PAYMENT_URL` with your Shopify draft order or invoice payment link.
